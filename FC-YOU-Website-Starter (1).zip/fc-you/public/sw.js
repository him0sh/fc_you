const CACHE_NAME = 'fc-you-shell-v1';
const SHELL = ['/', '/manifest.json', '/icons/fc-you.svg', '/icons/fc-you-192.png', '/icons/fc-you-512.png'];
self.addEventListener('install', event => { event.waitUntil(caches.open(CACHE_NAME).then(cache => cache.addAll(SHELL))); self.skipWaiting(); });
self.addEventListener('activate', event => { event.waitUntil(caches.keys().then(keys => Promise.all(keys.filter(key => key !== CACHE_NAME).map(key => caches.delete(key)))).then(() => self.clients.claim())); });
self.addEventListener('fetch', event => { const url = new URL(event.request.url); if (event.request.method !== 'GET' || url.pathname.startsWith('/api/')) return; event.respondWith(fetch(event.request).then(response => { if (response.ok && url.origin === self.location.origin) { const copy = response.clone(); caches.open(CACHE_NAME).then(cache => cache.put(event.request, copy)); } return response; }).catch(() => caches.match(event.request).then(cached => cached || caches.match('/')))); });
