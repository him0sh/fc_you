import { initializeApp, getApps, type FirebaseApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';
const config = { apiKey:process.env.NEXT_PUBLIC_FIREBASE_API_KEY, authDomain:process.env.NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN, projectId:process.env.NEXT_PUBLIC_FIREBASE_PROJECT_ID, storageBucket:process.env.NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET, messagingSenderId:process.env.NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID, appId:process.env.NEXT_PUBLIC_FIREBASE_APP_ID };
export function getFirebase(){ if(!config.apiKey || !config.projectId) throw new Error('Firebase is not configured. Add NEXT_PUBLIC_FIREBASE_* values to .env.local.'); const app:FirebaseApp=getApps().length?getApps()[0]:initializeApp(config); return {app,auth:getAuth(app),db:getFirestore(app)}; }
