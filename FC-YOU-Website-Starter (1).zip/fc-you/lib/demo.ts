export type Match = { id:string|number; league:string; country?:string; home:string; away:string; homeLogo?:string; awayLogo?:string; homeScore:number|null; awayScore:number|null; status:string; elapsed:number|null; kickoff?:string; source?:'api'|'manual' };
export const demoMatches: Match[] = [
 {id:'d1',league:'UEFA Champions League',country:'Europe',home:'Real Madrid',away:'Manchester City',homeScore:1,awayScore:1,status:'2H',elapsed:67,kickoff:'20:00'},
 {id:'d2',league:'Premier League',country:'England',home:'Arsenal',away:'Liverpool',homeScore:2,awayScore:0,status:'HT',elapsed:45,kickoff:'18:30'},
 {id:'d3',league:'La Liga',country:'Spain',home:'Barcelona',away:'Atlético Madrid',homeScore:0,awayScore:0,status:'NS',elapsed:null,kickoff:'21:00'},
 {id:'d4',league:'Serie A',country:'Italy',home:'Inter',away:'AC Milan',homeScore:3,awayScore:2,status:'FT',elapsed:90,kickoff:'17:00'},
 {id:'d5',league:'Bundesliga',country:'Germany',home:'Bayern Munich',away:'Borussia Dortmund',homeScore:1,awayScore:0,status:'1H',elapsed:28,kickoff:'19:30'},
 {id:'d6',league:'Iraqi Stars League',country:'Iraq',home:'Al-Shorta',away:'Al-Quwa Al-Jawiya',homeScore:null,awayScore:null,status:'NS',elapsed:null,kickoff:'20:15'},
 {id:'d7',league:'Ukrainian Premier League',country:'Ukraine',home:'Dynamo Kyiv',away:'Shakhtar Donetsk',homeScore:1,awayScore:0,status:'2H',elapsed:72,kickoff:'19:00'}
];
