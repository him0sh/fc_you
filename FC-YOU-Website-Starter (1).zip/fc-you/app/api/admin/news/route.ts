import { NextResponse } from 'next/server';
import { getAdminFirebase, requireAdmin } from '@/lib/firebase-admin';
export const revalidate = 0;
export async function GET(request: Request) {
  try { await requireAdmin(request); const { db } = getAdminFirebase(); const snap = await db.collection('news').orderBy('publishedAt', 'desc').limit(100).get(); return NextResponse.json({ articles: snap.docs.map(d => ({ id: d.id, ...d.data() })) }); }
  catch (e) { const msg = e instanceof Error ? e.message : 'Request failed'; return NextResponse.json({ error: msg }, { status: msg === 'Unauthorized' ? 401 : msg === 'Forbidden' ? 403 : 500 }); }
}
export async function POST(request: Request) {
  try {
    await requireAdmin(request); const body = await request.json();
    for (const key of ['title', 'summary', 'body', 'category']) if (typeof body[key] !== 'string' || !body[key].trim()) return NextResponse.json({ error: `${key} is required` }, { status: 400 });
    const imageUrl = typeof body.imageUrl === 'string' ? body.imageUrl.trim() : ''; if (imageUrl && !/^https:\/\//i.test(imageUrl)) return NextResponse.json({ error: 'Image URL must use HTTPS' }, { status: 400 });
    const now = new Date().toISOString(); const { db } = getAdminFirebase(); const doc = await db.collection('news').add({ title: body.title.trim().slice(0,160), summary: body.summary.trim().slice(0,300), body: body.body.trim().slice(0,10000), category: body.category.trim().slice(0,60), imageUrl, published: body.published !== false, publishedAt: now, createdAt: now });
    return NextResponse.json({ id: doc.id, ok: true }, { status: 201 });
  } catch (e) { const msg = e instanceof Error ? e.message : 'Request failed'; return NextResponse.json({ error: msg }, { status: msg === 'Unauthorized' ? 401 : msg === 'Forbidden' ? 403 : 500 }); }
}
export async function DELETE(request: Request) {
  try { await requireAdmin(request); const id = new URL(request.url).searchParams.get('id'); if (!id) return NextResponse.json({ error: 'id is required' }, { status: 400 }); const { db } = getAdminFirebase(); await db.collection('news').doc(id).delete(); return NextResponse.json({ ok: true }); }
  catch (e) { const msg = e instanceof Error ? e.message : 'Request failed'; return NextResponse.json({ error: msg }, { status: msg === 'Unauthorized' ? 401 : msg === 'Forbidden' ? 403 : 500 }); }
}
