import { NextResponse } from 'next/server';
import { getAdminFirebase } from '@/lib/firebase-admin';
export const revalidate = 0;
async function getManualMatches(date:string){
 try { const {db}=getAdminFirebase(); const snap=await db.collection('manualMatches').where('date','==',date).get(); return snap.docs.map(doc=>{const d=doc.data();return {id:`manual-${doc.id}`,league:d.league,country:'',home:d.home,away:d.away,homeScore:d.homeScore??null,awayScore:d.awayScore??null,status:d.status,elapsed:null,kickoff:d.kickoff?`${d.date}T${d.kickoff}:00+03:00`:d.date,source:'manual'};}); } catch { return []; }
}
export async function GET(request:Request){
 const {searchParams}=new URL(request.url); const date=searchParams.get('date') || new Date().toLocaleDateString('en-CA',{timeZone:'Asia/Baghdad'}); const manual=await getManualMatches(date); const key=process.env.API_FOOTBALL_KEY;
 if(!key) return NextResponse.json({source:'demo',message:'API key not configured',matches:manual});
 try { const base=process.env.API_FOOTBALL_BASE_URL || 'https://v3.football.api-sports.io'; const response=await fetch(`${base}/fixtures?date=${encodeURIComponent(date)}&timezone=Asia/Baghdad`,{headers:{'x-apisports-key':key},cache:'no-store'}); if(!response.ok) return NextResponse.json({source:'demo',message:`Football API returned ${response.status}`,matches:manual}); const payload=await response.json(); if(payload.errors && Object.keys(payload.errors).length) return NextResponse.json({source:'demo',message:'Football API rejected the request. Check key and plan.',matches:manual}); const apiMatches=(payload.response??[]).map((item:any)=>({id:item.fixture.id,league:item.league?.name,country:item.league?.country,home:item.teams?.home?.name,away:item.teams?.away?.name,homeLogo:item.teams?.home?.logo,awayLogo:item.teams?.away?.logo,homeScore:item.goals?.home,awayScore:item.goals?.away,status:item.fixture?.status?.short,elapsed:item.fixture?.status?.elapsed,kickoff:item.fixture?.date,source:'api'})); return NextResponse.json({source:'api',date,matches:[...apiMatches,...manual]},{headers:{'Cache-Control':'no-store'}}); }
 catch { return NextResponse.json({source:'demo',message:'Could not reach football API',matches:manual}); }
}
