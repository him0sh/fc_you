import { NextResponse } from 'next/server';

export const revalidate = 0;
const allowedLeagues = new Set(['39', '140', '135', '78', '61', '2', '203']);

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  const league = searchParams.get('league') || '39';
  const season = searchParams.get('season') || String(new Date().getFullYear());
  if (!allowedLeagues.has(league) || !/^20\d{2}$/.test(season)) {
    return NextResponse.json({ source: 'demo', message: 'Invalid league or season.', rows: [] }, { status: 400 });
  }
  const key = process.env.API_FOOTBALL_KEY;
  if (!key) {
    return NextResponse.json({ source: 'demo', message: 'API_FOOTBALL_KEY is not configured. Add it to .env.local to load official standings.', rows: [] });
  }
  try {
    const base = process.env.API_FOOTBALL_BASE_URL || 'https://v3.football.api-sports.io';
    const response = await fetch(`${base}/standings?league=${encodeURIComponent(league)}&season=${encodeURIComponent(season)}`, {
      headers: { 'x-apisports-key': key }, cache: 'no-store',
    });
    if (!response.ok) {
      return NextResponse.json({ source: 'demo', message: `Football API returned ${response.status}. Check your API plan and key.`, rows: [] });
    }
    const payload = await response.json();
    if (payload.errors && Object.keys(payload.errors).length) {
      return NextResponse.json({ source: 'demo', message: 'Football API rejected this league/season. Check your plan and API key.', rows: [] });
    }
    const item = payload.response?.[0];
    const leagueInfo = item?.league;
    const table = leagueInfo?.standings?.[0] ?? [];
    const rows = table.map((entry: any) => ({
      rank: entry.rank,
      team: entry.team?.name ?? 'Unknown team',
      logo: entry.team?.logo,
      played: entry.all?.played ?? 0,
      win: entry.all?.win ?? 0,
      draw: entry.all?.draw ?? 0,
      lose: entry.all?.lose ?? 0,
      goalsFor: entry.all?.goals?.for ?? 0,
      goalsAgainst: entry.all?.goals?.against ?? 0,
      goalDiff: entry.goalsDiff ?? 0,
      points: entry.points ?? 0,
      form: entry.form ?? null,
    }));
    return NextResponse.json({
      source: 'api',
      league: { name: leagueInfo?.name ?? '', country: leagueInfo?.country ?? '', logo: leagueInfo?.logo, season },
      rows,
    }, { headers: { 'Cache-Control': 'no-store' } });
  } catch {
    return NextResponse.json({ source: 'demo', message: 'Could not reach football API.', rows: [] });
  }
}
