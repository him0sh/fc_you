import { NextResponse } from 'next/server';
export const revalidate = 0;
export async function GET(request: Request) {
  const id = new URL(request.url).searchParams.get('id');
  if (!id || !/^\d+$/.test(id)) return NextResponse.json({ error: 'A numeric API fixture id is required.' }, { status: 400 });
  const key = process.env.API_FOOTBALL_KEY;
  if (!key) return NextResponse.json({ source: 'demo', message: 'Match details need an API-Football key.' }, { status: 503 });
  const base = process.env.API_FOOTBALL_BASE_URL || 'https://v3.football.api-sports.io'; const headers = { 'x-apisports-key': key };
  try {
    const [fixtureRes, eventsRes, lineupsRes, statsRes] = await Promise.all([
      fetch(`${base}/fixtures?id=${id}`, { headers, cache: 'no-store' }), fetch(`${base}/fixtures/events?fixture=${id}`, { headers, cache: 'no-store' }),
      fetch(`${base}/fixtures/lineups?fixture=${id}`, { headers, cache: 'no-store' }), fetch(`${base}/fixtures/statistics?fixture=${id}`, { headers, cache: 'no-store' }),
    ]);
    if (!fixtureRes.ok) return NextResponse.json({ error: `Football API returned ${fixtureRes.status}` }, { status: 502 });
    const [fixtureData, eventsData, lineupsData, statsData] = await Promise.all([fixtureRes.json(), eventsRes.ok ? eventsRes.json() : Promise.resolve({ response: [] }), lineupsRes.ok ? lineupsRes.json() : Promise.resolve({ response: [] }), statsRes.ok ? statsRes.json() : Promise.resolve({ response: [] })]);
    const f = fixtureData.response?.[0]; if (!f) return NextResponse.json({ error: 'Fixture not found. It may not be covered by your API plan.' }, { status: 404 });
    return NextResponse.json({ source: 'api', fixture: f, events: eventsData.response ?? [], lineups: lineupsData.response ?? [], statistics: statsData.response ?? [] }, { headers: { 'Cache-Control': 'no-store' } });
  } catch { return NextResponse.json({ error: 'Could not reach Football API.' }, { status: 502 }); }
}
