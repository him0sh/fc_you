import { NextResponse } from 'next/server';
import { getAdminFirebase, requireAdmin } from '@/lib/firebase-admin';
export const revalidate = 0;
const demoNews = [
  { id: 'demo-1', title: 'FC YOU is ready for your football day', summary: 'Connect your API key to load real fixtures, scores and standings.', body: 'This is a preview story. Add your own news from the secure admin dashboard after configuring Firebase.', category: 'FC YOU', imageUrl: '', publishedAt: '2026-10-01T12:00:00.000Z', source: 'demo' },
  { id: 'demo-2', title: 'Follow the matches that matter to you', summary: 'Save favourite matches and enable browser notifications for score changes.', body: 'Favourite matches are saved in this browser. Notifications require your permission and a supported browser.', category: 'Guide', imageUrl: '', publishedAt: '2026-10-02T12:00:00.000Z', source: 'demo' },
];
export async function GET() {
  try {
    const { db } = getAdminFirebase();
    const snap = await db.collection('news').orderBy('publishedAt', 'desc').limit(100).get();
    const articles = snap.docs.filter(d => d.data().published === true).slice(0, 50).map(d => ({ id: d.id, ...d.data(), source: 'firebase' }));
    return NextResponse.json({ source: 'firebase', articles }, { headers: { 'Cache-Control': 'no-store' } });
  } catch {
    return NextResponse.json({ source: 'demo', message: 'Configure Firebase Admin to publish and load your own articles.', articles: demoNews }, { headers: { 'Cache-Control': 'no-store' } });
  }
}
export async function POST(request: Request) {
  try {
    await requireAdmin(request);
    const body = await request.json();
    for (const key of ['title', 'summary', 'body', 'category']) if (typeof body[key] !== 'string' || !body[key].trim()) return NextResponse.json({ error: `${key} is required` }, { status: 400 });
    const imageUrl = typeof body.imageUrl === 'string' ? body.imageUrl.trim() : '';
    if (imageUrl && !/^https:\/\//i.test(imageUrl)) return NextResponse.json({ error: 'Image URL must use HTTPS' }, { status: 400 });
    const now = new Date().toISOString(); const { db } = getAdminFirebase();
    const doc = await db.collection('news').add({ title: body.title.trim().slice(0, 160), summary: body.summary.trim().slice(0, 300), body: body.body.trim().slice(0, 10000), category: body.category.trim().slice(0, 60), imageUrl, published: body.published !== false, publishedAt: now, createdAt: now });
    return NextResponse.json({ id: doc.id, ok: true }, { status: 201 });
  } catch (e) { const msg = e instanceof Error ? e.message : 'Request failed'; return NextResponse.json({ error: msg }, { status: msg === 'Unauthorized' ? 401 : msg === 'Forbidden' ? 403 : 500 }); }
}
export async function DELETE(request: Request) {
  try { await requireAdmin(request); const id = new URL(request.url).searchParams.get('id'); if (!id) return NextResponse.json({ error: 'id is required' }, { status: 400 }); const { db } = getAdminFirebase(); await db.collection('news').doc(id).delete(); return NextResponse.json({ ok: true }); }
  catch (e) { const msg = e instanceof Error ? e.message : 'Request failed'; return NextResponse.json({ error: msg }, { status: msg === 'Unauthorized' ? 401 : msg === 'Forbidden' ? 403 : 500 }); }
}
