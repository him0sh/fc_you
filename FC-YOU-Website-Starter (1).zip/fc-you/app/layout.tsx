import type { Metadata } from 'next';
import './globals.css';
export const metadata: Metadata = { title: 'FC YOU — Live Football Scores', description: 'Live football scores, fixtures, standings and match stories.', manifest: '/manifest.json', applicationName: 'FC YOU', appleWebApp: { capable: true, statusBarStyle: 'black-translucent', title: 'FC YOU' }, icons: { icon: '/icons/fc-you.svg', apple: '/icons/fc-you.svg' } };
export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) { return <html lang="ku"><body>{children}<script dangerouslySetInnerHTML={{__html: "if ('serviceWorker' in navigator) window.addEventListener('load', () => navigator.serviceWorker.register('/sw.js').catch(() => {}));"}} /></body></html>; }
