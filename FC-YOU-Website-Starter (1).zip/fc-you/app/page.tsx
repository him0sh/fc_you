import FCYouApp from '@/components/FCYouApp';
export default function Home(){return <FCYouApp/>}
